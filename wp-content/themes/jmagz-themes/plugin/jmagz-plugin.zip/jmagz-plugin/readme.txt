1.0.0
- Initial Release

1.0.1
- Fix compatibility with older php version 5.3

1.0.2
- Fix compatibility with older php version 5.2

1.0.3
- fix side ads size
- add option to have option on front page query
- unique content group for landing page